﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.TextFormatting;
using System.Windows.Shapes;
using System;
using System.IO;

namespace _3_Project
{
    /// <summary>
    /// Interaction logic for KarakterGen.xaml
    /// </summary>
    public partial class KarakterGen : Window
    {
        public const int maxPoints = 15;
        public int strenght;
        public int agility;
        public int luck;
        public string kaszt;
        public string race;
        public string name;
        private RandomNameManager randomNameManager;

        public KarakterGen()
        {
            InitializeComponent();
            strenght = 3;
            agility = 3;
            luck = 3;
            kaszt = "warrior";
            race = "human";
            name = "";
            randomNameManager = new RandomNameManager();
        }

        public void IncLuck(object sender, RoutedEventArgs e)
        {
            if (this.RemainingPoints() > 0)
            {
                this.luck++;
                this.RefreshPoints(); ;
            }
        }

        public void DecLuck(object sender, RoutedEventArgs e)
        {
            if (this.luck > 0)
            {
                this.luck--;
                this.RefreshPoints();
            }
        }

        public void IncStrength(object sender, RoutedEventArgs e)
        {
            if (this.RemainingPoints() > 0)
            {
                this.strenght++;
                this.RefreshPoints();
            }
        }

        public void DecStrength(object sender, RoutedEventArgs e)
        {
            if (this.strenght > 0)
            {
                this.strenght--;
                this.RefreshPoints();
            }
        }

        public void IncAgility(object sender, RoutedEventArgs e)
        {
            if (this.RemainingPoints() > 0)
            {
                this.agility++;
                this.RefreshPoints();
            }
        }

        public void DecAgility(object sender, RoutedEventArgs e)
        {
            if (this.agility > 0)
            {
                this.agility--;
                this.RefreshPoints();
            }
        }

        public void ChooseWarrior(object sender, RoutedEventArgs e)
        {
            this.kaszt = "warrior";
            this.strenght = 5;
            this.agility = 2;
            this.luck = 2;
            RefreshPoints();
            SetCharacterImage();
        }

        public void ChooseMage(object sender, RoutedEventArgs e)
        {
            this.kaszt = "mage";
            this.strenght = 2;
            this.agility = 3;
            this.luck = 4;
            RefreshPoints();
            SetCharacterImage();
        }

        public void ChooseHunter(object sender, RoutedEventArgs e)
        {
            this.kaszt = "hunter";
            this.strenght = 2;
            this.agility = 6;
            this.luck = 1;
            RefreshPoints();
            SetCharacterImage();
        }

        public void ChooseHuman(object sender, RoutedEventArgs e)
        {
            this.race = "human";
            SetCharacterImage();
        }

        public void ChooseOrk(object sender, RoutedEventArgs e)
        {
            this.race = "ork";
            SetCharacterImage();
        }

        public void ChooseGnome(object sender, RoutedEventArgs e)
        {
            this.race = "gnome";
            SetCharacterImage();
        }

        public void ChooseElf(object sender, RoutedEventArgs e)
        {
            this.race = "elf";
            SetCharacterImage();
        }

        private void SetCharacterImage()
        {

            string imageFolder = "kepek";
            //string imageName = this.race + "_" + this.kaszt;
            string imageName = "test";
            string imagePath = System.IO.Path.Combine(imageFolder, $"{imageName}.jpg");

   

            BitmapImage image = new BitmapImage();
            image.BeginInit();
            image.UriSource = new Uri(imagePath, UriKind.Relative);
            image.EndInit();

            CharacterImage.Source = image;
          
        }


        public void GetRandomName(object sender, RoutedEventArgs e)
        {
            NameInput.Text = randomNameManager.GetRandomName();
        }

        public void SaveCharacter(object sender, RoutedEventArgs e)
        {
            this.name = NameInput.Text;
            if (!this.Valid())
            {
                NameInput.Text = "Please enter your name here...";
            }
            else
            {
                Character newCharacter = new Character(this.name, this.kaszt, this.race, this.strenght, this.luck, this.agility);
                Console.WriteLine(newCharacter.ToString());
                CharacterManager.SaveCharacter(newCharacter);
            }
        }

        private int RemainingPoints()
        {
            return maxPoints - this.strenght - this.agility - this.luck;
        }

        private void RefreshAvailablePoints()
        {
            AvailablePoints.Text = "Remaining Points: " + RemainingPoints().ToString();
        }

        private void RefreshPoints()
        {
            AgilityText.Text = this.agility.ToString();
            StrengthText.Text = this.strenght.ToString();
            LuckText.Text = this.luck.ToString();
            RefreshAvailablePoints();
        }

        private bool Valid()
        {
            if (string.IsNullOrEmpty(this.name))
            {
                return false;
            }
            return true;
        }
    }
}
