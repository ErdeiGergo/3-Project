# 3-Project
# Csapattagok: Bárdos Márk😎, Kovács Botond😎, Erdei Gergő😎
# 1. Feladat: Boti
# 2. Feladat: Geri
# 3. Feladat: Bárdos Márkos
